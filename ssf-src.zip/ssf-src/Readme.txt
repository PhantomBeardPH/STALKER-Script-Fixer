This is the python export of the project that you can edit with (what ever script editor you choose, ex. notepad++, etcs)

This project was wrapped using 'pyinstaller'. 
NOTE: Update to latest python for complete packaging.

Please don't forget to credit:
'PhantomBeardPH' mangganer2023@gmail.com 

Good hunting! :)